This directory contain the code for my word prediction program (Eliza Ngrams).
It contain the deployment code only, not the code to build the language model, or
the code to test it.

Since the interface is complex, I do not use ui.R, but build a custom HTML interface
which reside in the "www" directory.