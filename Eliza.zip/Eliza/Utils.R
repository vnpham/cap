load("LangModel1.rda")

#----------------------------------------------------------------------
is.upper <- function(word) {
  (strsplit(word, "")[[1]][[1]]) %in% LETTERS
}

#----------------------------------------------------------------------
lastchar <- function(word) {
  substr(word, nchar(word), nchar(word))
}

#----------------------------------------------------------------------
strtrim <- function (x) gsub("^\\s+|\\s+$", "", x)

#----------------------------------------------------------------------
bsearch <- function(val,tab,L=1L, H=length(tab)) {
  if (is.na(val)) return(0L)
  while (H >= L) { 
    M <- L + (H - L) %/% 2L 
    if (tab[M] > val) H <- M - 1L 
    else if (tab[M] < val) L <- M + 1L 
    else return(M) 
  } 
  return(L - 1L) 
}

#----------------------------------------------------------------------
# This is the original get ID function using binary search with the
# indexed array.
#----------------------------------------------------------------------
# GetID <- function(languageModel, word) {
#   bsearch(word, languageModel$dict)
# }

#----------------------------------------------------------------------
# This is the get ID function that use the separate dictionary table.
# The reason for its existence is because the order that R sort words.
# For example, in my machine, the result of sort(c("a","A","B","b"))
# is the list c("a" "A" "b" "B").  This is not the same as in most language
# and this behavior is locale dependent.  It is unfortunate (or maybe
# fortunate) that when I load the application to the Shiny.io server,
# it use a different locale (I think) and the order is totally different.
# As a result, function binary search does not work with the existing
# index anymore.  It is possible to rewrite the current binary search to
# allow a callback function to handle the order independent of the locale.
# However, it is late in the project, and I don't want any surprise.  So
# I create a separate table to store the dictionary along with the
# index.  It's just an insurance fix.  I think the other solution is
# more elegant.
# Note: as a result of the separate dictionary, the size of the data
# is now 4.6Mb instead of less than 4Mb.  Since this is only a temporary
# insurace fix, I still count 4Mb as the official size of the data.
#----------------------------------------------------------------------
GetID <- function(languageModel, word) {
  unname(unlist(dict[word,2,with=FALSE]))
}

#----------------------------------------------------------------------
Word2ID <- function(languageModel, wordList) {
  sapply(wordList, function(x) GetID(languageModel,x), USE.NAMES=FALSE)
}

#----------------------------------------------------------------------
ID2Word <- function(languageModel, idList) {
  languageModel$dict[idList]
}