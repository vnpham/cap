#======================================================================
# Predict next word given a number of prefixes
# Author: Vinh N. Pham
#======================================================================

#----------------------------------------------------------------------
# Predict next word within a specific ngram order
#----------------------------------------------------------------------
PredictWordsFixed <- function(ngramTable, wordList, order) {
  nextWords <- tail(unname(unlist(ngramTable[[order-1]][as.list(wordList)])),5)
  nextWords[nextWords != 0 & !is.na(nextWords)]
}


#----------------------------------------------------------------------
# Predict next word given a list of prefix words
# Assumption:
#   - Maximum of length parameter is 6
#----------------------------------------------------------------------
PredictNextWord <- function(languageModel,
                            wordList,
                            length=1,
                            order=attr(languageModel, "maxOrder")) {
  
  n <- length(wordList)
  if (n >= order) {
    n <- order - 1
  }
  
  wordList <- Word2ID(languageModel, wordList)
  
  result <- c()
  for (i in n:1) {
    rowResult <- PredictWordsFixed(languageModel$ngram,
                                    tail(wordList,i), i+1)
    #cat("rowResult: ", rowResult,"\n")
    result <- append(result, rowResult)
    if (length(result) >= length) break
  }
  
  if (length(result) < length) {
    result <- c(result, languageModel$uni)
  }
  ret <- unique(result)[1:length]
  
  ret <- ID2Word(languageModel, ret)
  
  # if all else fail
  if (length(ret) == 0 || is.na(ret))
    ret <- ID2Word(head(languageModel$uni, length))
  
  ret
}

#----------------------------------------------------------------------
# Predict next word given the prefix string
#----------------------------------------------------------------------
NextWords <- function(languageModel,
                      inputString,
                      length=1,
                      order=attr(languageModel, "maxOrder")) {
  lastSentence <- strtrim(last(strsplit(inputString, "[.]")[[1]]))
  
  if (length(lastSentence) > 0 && lastSentence !="") {
    sentenceWordList <- strsplit(lastSentence, " ")[[1]]
    wordList <- sentenceWordList
    
    if (lastchar(inputString) != " ") {
      wordList <- head(wordList,-1)
    }

    if (length(wordList) > 0)
      result <- PredictNextWord(languageModel, c("<s>", wordList), length, order)
    else
      result <- head(c("The", "I", "You", "A", "This", "That"),length)  
  }
  else
    result <- head(c("The", "I", "You", "A", "This", "That"),length)

  result
}
